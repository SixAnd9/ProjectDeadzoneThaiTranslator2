package com.example.deadzonetranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 41
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "Project Deadzone Thai Translator\n\nแปลข้อความอังกฤษบนหน้าจอเป็นภาษาไทย"
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "1) อนุญาตให้แสดงทับแอปอื่น"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2) เริ่มจับภาพและแปลหน้าจอ"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nวิธีใช้: อนุญาตสิทธิ์ → เริ่มจับภาพ → ยืนยันการแชร์หน้าจอ → กลับเข้าเกม\n\nรุ่นต้นแบบนี้ใช้ OCR อ่านข้อความ แล้วแสดงคำแปลเป็นแถบลอยด้านบน ไม่ได้ลบตัวอักษรเดิมออกจากภาพเกม"
            textSize = 14f
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(service)
            finish()
        }
    }
}
