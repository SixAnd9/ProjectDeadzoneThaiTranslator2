package com.example.deadzonetranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: TextView? = null
    private var lastText = ""
    private var busy = AtomicBoolean(false)
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        if (intent == null) return START_NOT_STICKY
        thread = HandlerThread("screen-ocr").also { it.start() }
        handler = Handler(thread.looper)
        val code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        if (data != null) startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "translator"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "ตัวแปลภาษา", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("กำลังแปลหน้าจอ")
                .setSmallIcon(android.R.drawable.ic_menu_search).build()
        else Notification.Builder(this).setContentTitle("กำลังแปลหน้าจอ")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        startForeground(7, notification)
    }

    private fun startCapture(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (busy.compareAndSet(false, true)) processImage(image) else image.close()
        }, handler)
        display = projection?.createVirtualDisplay("DeadzoneTranslator", width, height,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler)
        showOverlay("กำลังอ่านข้อความในเกม…")
    }

    private fun processImage(image: Image) {
        try {
            val bitmap = image.toBitmap()
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val text = result.text.trim()
                    if (text.isNotBlank() && text != lastText && text.length <= 700) {
                        lastText = text
                        translate(text) { translated -> handler.post { showOverlay(translated) } }
                    }
                }
                .addOnCompleteListener { busy.set(false) }
        } catch (_: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy.set(false)
        }
    }

    private fun translate(source: String, done: (String) -> Unit) {
        Thread {
            try {
                val q = URLEncoder.encode(source, "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=en|th")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val translated = JSONObject(body).getJSONObject("responseData").getString("translatedText")
                done(translated.ifBlank { "ไม่พบคำแปล" })
            } catch (_: Exception) {
                done("เชื่อมต่อบริการแปลภาษาไม่ได้")
            }
        }.start()
    }

    private fun showOverlay(text: String) {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (overlay == null) {
            overlay = TextView(this).apply {
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xCC202020.toInt())
                textSize = 16f
                setPadding(18, 12, 18, 12)
                maxLines = 5
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP; y = 70 }
            wm.addView(overlay, params)
        }
        overlay?.text = text
    }

    override fun onDestroy() {
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        thread.quitSafely()
        super.onDestroy()
    }
}

/* Image-to-Bitmap helper using the first plane buffer. */
private fun Image.toBitmap(): android.graphics.Bitmap {
    val plane = planes[0]
    val buffer = plane.buffer
    val pixelStride = plane.pixelStride
    val rowStride = plane.rowStride
    val rowPadding = rowStride - pixelStride * width
    val bmp = android.graphics.Bitmap.createBitmap(
        width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888)
    bmp.copyPixelsFromBuffer(buffer)
    return android.graphics.Bitmap.createBitmap(bmp, 0, 0, width, height)
}
